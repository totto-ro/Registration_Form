console.log("it works!")

function removeButton(){
    let deleteJoin = document.querySelector('.b1');
    deleteJoin.remove();
}



let heartIcon = document.querySelectorAll('.heart');
console.log(heartIcon);

let numCount = document.querySelectorAll('.num');
console.log(numCount);

let addNum = 0;

function addlikes(event){
    addNum = addNum + 1;
    for(let i = 0; i < numCount.length; i++){
        numCount[i].innerHTML = addNum;
        console.log(addNum);
    }
}

for(let i = 0; i < heartIcon.length; i++){
    heartIcon[i].addEventListener('click', addlikes );
}



function displayText(event){
    console.log(event.value);
}

let input = document.querySelector('#searh');

function displaySearh(){
    alert(`You are searching for ${input.value}` );
}



